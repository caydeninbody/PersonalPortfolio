"""
    File Name: armourClass.py
    Purpose: 
        A child class of Item Class
    Variables created, in order of creation:
   damage = item's damage
   abilitySlots = item's ability slots
    Functions
        __init__ = initializes class
        __str__ = returns a string format of the object
        setDamage = sets damage property
        getDamage = gets damage property
        damageIncrease = will increase the damage based on a specified percent
        abilitySlotIncrease = will increase ability slots by specified amount
    First Create Date: 11/01/2023
    Last Update Date: 11/07/2023
    Author: Cayden Inbody
    Version: 0.1 """
import itemClass

class Weapon(itemClass.Item):
    damage = 0
    
    def __init__(self, name, weight, damage, abilitySlots):
        super().__init__(name, weight)
        self.damage = damage
        self.abilitySlots = abilitySlots
        
    def __str__(s):
        return f"Item Type: Weapon \nItem Name: {s.name} \nItem Damage: {s.damage} \nItem Weight: {s.weight}"
    
    def getDamage(s):
        return s.damage
    
    def getAbilitySLots(s):
        return s.abilitySlots
    
    def setAbilitySlots(s, abilitySlots):
        s.abilitySlots = abilitySlots; 
    
    def setDamage(s, damage):
        s.damage = damage
        
    def damageIncrease(s, increasePercent):
        s.damage = s.damage * increasePercent; 
        
    def abilitySlotIncrease(s, increaseAmount):
        s.abilitySlots = s.abilitySlots + increaseAmount; 
        