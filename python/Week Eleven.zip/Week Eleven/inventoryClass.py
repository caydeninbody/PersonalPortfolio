"""
    File Name: inventoryClass.py
    Purpose: 
        An inventory class to create an inventory system
    Variables created, in order of creation:
   items = [] list of items 
    Functions
        __init__ = initializes class
        __str__ = returns a string format of the object
        setItems  = Sets items property
        getItems = gets items property
        pickupItem = will add an item to list items
    First Create Date: 11/01/2023
    Last Update Date: 11/07/2023
    Author: Cayden Inbody
    Version: 0.1 """
import itemClass
import inspect

class Inventory:
    items = [] 
    
    def __init__(self, items):
        self.items = items; 
        
    def __str__(s):
        return f"Items: {s.items}"
        
    def setItems(s, items):
        s.items = items; 
    
    def getItems(s):
        for itemClass.Item in s.items: 
            print(itemClass.Item)
    
    def pickupItem(s, item):
        s.items.append(item)          
            
        