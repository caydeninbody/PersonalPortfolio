"""
    File Name: executable.py
    Purpose: 
       Executable file that will create a character based off user input
    Special Requirement:
        Demonstrates Object Oriented Programming, setters/getters, other functions, object instances.
    Variables created, in order of creation:
   characterName = gets user input for character name
   characterType = gets user input to select character class which represents starting inventory and health
   selectedClass = will be set to whatever selection made by player
   daggers = weapon Item
   longSword = weapon Item
   doubleSidedAxe = weapon Item
   hoodedArmour = armour Item
   ironArmour = armour Item
   plateArmour = armour Item
   goldenKey = parent Item
   lightInventory = inventory for light class
   mediumInventory = inventory for medium class
   heavyInventory = inventory for heavy class
   characterHealth = value set based on selected class
   newHealth = new health after being given 20 health
    Functions
        import characterClass
        import inventoryClass
        import itemClass
        import weaponClass
        import armourClass
    First Create Date: 11/06/2023
    Last Update Date: 11/14/2023
    Author: Cayden Inbody
    Version: 0.2 """
#imports all classes made
import characterClass; 
import inventoryClass; 
import weaponClass; 
import armourClass; 
import itemClass; 


print("CREATE A CHARACTER")
print("===================")
# getting input for character name
print("Step 1.)")
characterName = input("Enter a name for your character:\n")
# selecting a class to set values for character health and inventory
print("\nStep 2.)")
print("Select Which class you would like, this will represent your health:")
print("A.) Light")
print("B.) Medium")
print("C.) Heavy")
characterType = input("Enter either A , B , C . correlating to which class you will create.\n")
# checking if user input is valid
checking = True; 
while checking:
    if characterType.upper() == "A":
        print(f"{characterName} will be a light class with 30 Health")
        selectedClass = "Light"
        checking = False; 
    elif characterType.upper() == "B":
        print(f"{characterName} will be a medium class with 50 Health")
        selectedClass = "Medium"
        checking = False; 
    elif characterType.upper() == "C":
        print(f"{characterName} will be a Heavy class with 100 Health")
        selectedClass = "Heavy"
        checking = False; 
    else:  # if wrong input
        characterType = input("Looks like something went wrong, please attempt your selection again by typing A , B , or C.\n")

print(f"\n{characterName} will be given the inventory based on the class selected.") 

# creating weapon items
daggers = weaponClass.Weapon("Daggers", 45, 5, 3)
longSword = weaponClass.Weapon("Long Sword", 30, 10, 4)
doubleSidedAxe = weaponClass.Weapon("Double Sided Axe", 40, 25, 1)

# creating armour items
hoodedArmour = armourClass.Armour("Hooded Armour", 10, 2, 0)
ironArmour = armourClass.Armour("Iron Armour", 22, 19, 2)
plateArmour = armourClass.Armour("Plate Armour", 30, 30, 4)

# creating inventories with created items above
lightInventory = [daggers, hoodedArmour]
mediumInventory = [longSword, ironArmour]
heavyInventory = [doubleSidedAxe, plateArmour]

# setting health and inventory for character based on player selection
if selectedClass == "Light":
    characterHealth = 30
    characterInventory = lightInventory; 
elif selectedClass == "Medium":
    characterInventory = mediumInventory; 
    characterHealth = 50
elif selectedClass == "Heavy":
    characterInventory = heavyInventory; 
    characterHealth = 100

# initializing character based on user input from above
characterOne = characterClass.Character(characterName, characterHealth, characterInventory)

# demonstrating getName()
print(f"{characterOne.getName()} has now been succesfully created.")

# demonstrating getters and setters.
print(f"\nI will be giving {characterOne.name} an additional 20 health")
newHealth = characterOne.getHealth() + 20 # base health + health I am giving character
characterOne.setHealth(newHealth)

print(f"{characterOne.name}'s health is now {characterOne.getHealth()}") 

# demonstrates other function, takeDamage(damage)
print(f"Although {characterOne.name} was just given 20 health, they will now take damage from the {longSword.name}")
characterOne.takeDamage(longSword.damage)
print(f"{characterOne.name} has taken {longSword.damage} from {longSword.name}.")

print(f"\nUp to now all of our weapons and armour have been created with new child classes so this way armour won't accidentally do damage and weapons won't accidentally protect someone from an attack.")

print(f"\nNow let's create an item that won't be a weapon or armour. This Item instead will be a key, this key will be from the parent class.")
print(f"generating key...")
# generating an object of parent class
goldenKey = itemClass.Item("THE Golden Key", 500)

print(f"KEY HAS BEEN GENERATED. Now you will be granted the key in your inventory.")
#characterOne.inventory.pickupItem(goldenKey)
print(f"{characterOne.name} now has {goldenKey.name}")

print("\nI'm going to increase the weight of all weapons by 50%")
# demonstrating parent method
daggers.increaseWeight(.5)
longSword.increaseWeight(.5)
doubleSidedAxe.increaseWeight(.5)

print(f"{daggers.name} has a weight of {daggers.weight} \n{longSword.name} has a weight of {longSword.weight} \n{doubleSidedAxe.name} has a weight of {doubleSidedAxe.weight}")

print("\nNow lets change the damage of weapon items by setting new values")
# demonstrating setting child properties
daggers.setDamage(50)
longSword.setDamage(35)
doubleSidedAxe.setDamage(45)

print(f"\nI've changed my mind with increasing the weight of all weapons by 50%, so lets set some custom weights.")
# demonstrating setting parent properties
daggers.setWeight(7)
longSword.setWeight(13)
doubleSidedAxe.setWeight(27)

print("\n I will now be giving every weapon an upgrade of 2 to their ability slots.")
# demonstrating child methods
daggers.abilitySlotIncrease(2)
longSword.abilitySlotIncrease(2)
doubleSidedAxe.abilitySlotIncrease(2)
# printing out all parent classes and child classes. Child class is seperated by the two child classes I made
print(f"Here will be all of the items generated in this file")
print("\nPARENT CLASS ITEMS")
print("====================")
print(f"{goldenKey.__str__()}")

print("\nCHILD CLASS ITEMS.")
print("====================")
print("WEAPONS")
print(f"\n{daggers.__str__()}")
print(f"\n{longSword.__str__()}")
print(f"\n{doubleSidedAxe.__str__()}")
print("\nARMOUR")
print(f"\n{hoodedArmour.__str__()}")
print(f"\n{ironArmour.__str__()}")
print(f"\n{plateArmour.__str__()}")

print("\nCharacter Creation is now done.")