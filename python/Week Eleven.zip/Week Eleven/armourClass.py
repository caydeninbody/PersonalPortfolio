"""
    File Name: armourClass.py
    Purpose: 
        A child class of Item class
    Variables created, in order of creation:
   protection = item's protection stat
   upgradeSlots = amount of upgrade slots
    Functions
        __init__ = initializes class
        __str__ = returns a string format of the object
        setProtection = sets protection property
        getProtection = gets protection property
        setUpgradeSlots = set upgradeSlots property
        getUpgradeSlots = get upgradeSlots property
        increaseUpgradeSlots = will increase Upgrade Slots amount by specified amount
    First Create Date: 11/13/2023
    Last Update Date: 11/14/2023
    Author: Cayden Inbody
    Version: 0.1 """
import itemClass; 

class Armour(itemClass.Item):
    protection = 0; 
    upgradeSlots = 0; 
    
    def __init__(self, name, weight, protection, upgradeSlots):
        super().__init__(name, weight)
        self.protection = protection
        self.upgradeSlots = upgradeSlots
        
    def __str__(s):
        return f"Item Type: Weapon \nItem Name: {s.name} \nItem Protection: {s.protection} \nUpgrade Slots: {s.upgradeSlots} \nItem Weight: {s.weight}"
    
    def getProtection(s):
        return s.protection
    
    def getUpgradeSlots(s):
        return s.upgradeSlots
    
    def setUpgradeSlots(s, upgradeSlots):
        s.upgradeSlots = upgradeSlots; 
        
    def setProtection(s, protection):
        s.protection = protection
    
    def increaseProtection(s, increasePercent):
        s.protection = s.protection * increasePercent
        
    def increaseUpgradeSlots(s, increaseAmount):
        s.upgradeSlots = s.upgradeSlots + increaseAmount; 