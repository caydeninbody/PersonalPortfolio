"""
    File Name: characterClass.py
    Purpose: 
        A character class to create playable characters of different types.
    Variables created, in order of creation:
   name = is character's name
   health = character's health
   inventory = an object that holds the inventory list
    Functions
        __init__ = initializes class
        __str__ = returns a string format of the object
        setName = Sets name property
        setHealth = sets health property
        setInventory = sets inventory property
        getName = gets name property
        getHealth = gets health property
        getInventory = gets inventory property
        takeDamage = will lower the characters health by the amount of damage specified
    First Create Date: 11/01/2023
    Last Update Date: 11/07/2023
    Author: Cayden Inbody
    Version: 0.1 """
import inventoryClass; 
import itemClass;

class Character:
    name = ""
    health = 100; 
    inventory = inventoryClass.Inventory([])
    
    def __init__(self, name, health, inventory):
        self.health = health; 
        self.name = name; 
        self.inventory = inventory; 

    def __str__(s):
        return f"\nCharacter Name: {s.name}\nHealth: {s.health}.\nItems: \n{s.inventory.getItems()}"
    
    def setName(s, name):
        s.name = name; 
        
    def setHealth(s, health):
        s.health = health; 
    
    def setInventory(s, inventory):
        s.inventory = inventory; 
        
    def getName(s):
        return s.name
    
    def getHealth(s):
        return s.health
    
    def getInventory(s):
        return s.inventory
    
    def takeDamage(s, damage):
        s.health = s.health - damage
        if s.health <= 0:
            print(f"{s.name} has died!")
            print(f"{s.name}'s health will be set to 0")
            s.health = 0; 
        else:
            print(f"{s.name}'s health is now {s.health}")
    
