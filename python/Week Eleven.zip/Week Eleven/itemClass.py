"""
    File Name: itemClass.py
    Purpose: 
        An item class to create items of different types.
    Variables created, in order of creation:
   name = is item's name
   damage = item's damage
   protection = item's protection stat
   weight = item's weight stat
    Functions
        __init__ = initializes class
        __str__ = returns a string format of the object
        setName = Sets name property
        setWeight = sets weight property
        getName = gets name property
        getWeight = gets weight property
        increaseWeight = increase weight property by specified percent
    First Create Date: 11/01/2023
    Last Update Date: 11/14/2023
    Author: Cayden Inbody
    Version: 0.2 """
class Item:
    name = ''
    weight = 0
    
    def __init__(self, name, weight):
        self.name = name; 
        self.weight = weight
        
    def __str__(s):
        return f"Item Name: {s.name} \nItem Weight: {s.weight}"
    
    def setName(s, name):
        s.name = name
                
    def setProtection(s, protection):
        s.protection = protection
        
    def setWeight(s, weight):
        s.weight = weight
        
    def getName(s):
        return s.name
    
    def getWeight(s):
        return s.weight; 
    
    def increaseWeight(s, increasePercent):
        s.weight = s.weight + (s.weight * increasePercent)

