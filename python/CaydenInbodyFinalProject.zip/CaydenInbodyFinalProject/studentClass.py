"""
    File Name: studentClass.py
    Purpose: 
        A child class of User class
    Variables created, in order of creation:
   username = username for Student
   password = password for Student
   firstName = First Name of Student
   lastName = Last Name of Student
    Functions
        __init__ = initializes class
        __str__ = returns a string format of the object
        setPassword = sets password property
        getPassword = gets password property
        setUsername = set username property
        getUsername = get username property
        setFirstName = set firstName property
        getFirstName = gets firstName property
        setLastName = set lastName property
        getLastName = gets lastName property
    First Create Date: 11/21/2023
    Last Update Date: 11/28/2023
    Author: Cayden Inbody
    Version: 0.1 """
from userClass import User; 

class Student(User):    
    firstName = "" # Student First Name
    lastName = "" # Student Last Name
    
    def __init__(s, username, password, firstName, lastName):
        super().__init__(username, password) # inherits username and password property from parent class
        s.firstName = firstName
        s.lastName = lastName