Project Description:
    To store and edit student information regarding class. Also allows student to view their enrolled courses. 
Files Included in the Package:
    Admin Module:
        Executable: adminStart.py
        Class File: adminClass.py
        Utility File: utilityFile.py
    Student Module:
        Executable: studentStart.py
        Class File: studentClass.py
        Utility File: utilityFile.py
    Other:
        Info File: readMe.txt
        Class File: courseClass.py
        Log In File (Will contain valid username/password combos for adminStart.py): admin.csv