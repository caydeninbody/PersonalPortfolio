"""
    File Name: userClass.py
    Purpose: 
        Parent Class
    Variables created, in order of creation:
   username = username for User
   password = password for User
    Functions
        __init__ = initializes class
        __str__ = returns a string format of the object
        setPassword = sets password property
        getPassword = gets password property
        setUsername = set username property
        getUsername = get username property
    First Create Date: 11/21/2023
    Last Update Date: 11/28/2023
    Author: Cayden Inbody
    Version: 0.1 """
# parent class
class User():
    username = ""
    password = ""

    def __init__(s, username, password):
        s.username = username; 
        s.password = password; 
        
    def __str__(s):
        return f"Username: {s.username} \nPassword: {s.password}"
    
    def setUsername(s, username):
        s.username = username; 
    
    def setPassword(s, password):
        s.password = password; 
        
    def getUsername(s):
        return f"{s.username}"

    def getPassword(s):
        return f"{s.password}"