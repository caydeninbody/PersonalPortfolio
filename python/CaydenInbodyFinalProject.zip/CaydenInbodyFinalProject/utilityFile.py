"""
    File Name: utilityFile.py
    Purpose: 
        Utility file that contains functions used in studentStart.py and adminStart.py
    Variables created, in order of creation:
   file = opening the loginFile in read mode
   tries = tries currently at
   triesAllowed = how many login attempts allowed
   username = entry for username
   password = entry for password
   info = returned value of whatever type of info is being checked for uniqueness
   fileAppend = opening a file in append mode
   fileRead = opening a file in read mode
   fileHeader = header for file 
   courseNumber = unique course Number
   selectedTask = Whatever number that is selected by user that corresponds with a task
    Functions
        login(username,password,loginFile) = Logs user in and verifies username and password input.
        checkUniqueInfo(info,infoType,fileName) = checks the unique info, needs the info being checked, the type of info, and name of file where   the info is being checked at.
        addNewStudent(studentUsername,studentPassword,studentFirstName,studentLastName) = adds a new student to a csv file so the student can be enrolled in courses and check their enrollment status.
        addNewCourse(courseTitle, courseNumber) = Adds a new course with it's course number to a csv file which allows an Admin to put students into courses. 
         addNewEnrollment(studentUsername, courseNumber) = Enrolls a student into course based on username and courseNumber
         seeAllInfo(fileName) = Will display all info and header of a file on screen. Used to see student info and enrolled courses.
         adminControl()= Displays choices for tasks after logging in. This will run a function based on user input
         createStudent(username,password) = Will create a student object based off logging in. 
         displayCourses(username) = Will display all courses student is enrolled in
    First Create Date: 11/21/2023
    Last Update Date: 11/28/2023
    Author: Cayden Inbody
    Version: 0.1 """
import os; # importing os
from studentClass import Student; # imports Student Class

# Logs user in
def login(username,password,loginFile): 
    if os.path.isfile(loginFile): # checks if login file exists
        file = open(loginFile, "r") 
        tries = 0
        triesAllowed = 5;  # only 5 attempts allowed
        while tries < triesAllowed: # Runs five times before exiting
            if f"{username.lower()},{password.lower()}" in file.read(): # if username and password are correct
                print(f"Successful login for user {username}")
                break # breaks after logging in
            else: # incorrect combination
                print("Incorrect Login info, please retype info correctly") 
                username = input("Username: ").lower() # re-enter info
                password = input("Password: ").lower() # re-enter info
                tries += 1
                file.seek(0) # resets place where we were reading
        
        if tries == triesAllowed: # Too many incorrect combinations
            print("Too many incorrect tries, goodbye")
            exit()
    else:
        if loginFile == 'studentLogin.csv': # if the student file doesn't exist informs that student must be added first
            print("Error: Must add student info first in the Admin Module.")
            print("Goodbye")
        exit()
        
# checks if info entered is unique in specified file
def checkUniqueInfo(info,infoType,fileName):
    file = open(fileName, "r") # opens file in read mode
    while info.lower() in file.read(): # info is not unique
        info = input(f"{infoType} must be unique, please try again: ").lower()
    return info.lower() # info is unique
        
# adds new student to the system in a csv file.
def addNewStudent(studentUsername, studentPassword, studentFirstName, studentLastName):
    fileAppend = open("studentLogin.csv", 'a') # opens file in append mode
    fileRead = open("studentLogin.csv", 'r') # opens file in read mode
    fileHeader = "studentUsername,studentPassword,studentFirstName,studentLastName" # header for orginization 
    if fileHeader not in fileRead.read(): # if the file header hasn't been added yet, add it
        fileAppend.write(fileHeader) 
        
    studentUsername = checkUniqueInfo(studentUsername, 'Student Username','studentLogin.csv') # checks if student username is unique
    fileAppend.write(f'\n{studentUsername.lower()},{studentPassword.lower()},{studentFirstName.lower()},{studentLastName.lower()}') # writes info given (adds new student)
    fileAppend.close()
        
# Adds new course to csv file, allows students to be registered by Admin in that course
def addNewCourse(courseTitle, courseNumber):
    fileAppend = open("courses.csv", 'a') # opens file in append mode
    fileRead = open("courses.csv", 'r') # opens file in read mode
    fileHeader = "courseTitle,courseNumber" # header for orginzations
    if fileHeader not in fileRead.read(): # if file header hasn't been added yet
        fileAppend.write(fileHeader)
    
    courseNumber = checkUniqueInfo(courseNumber, 'Course Number','courses.csv') # checks if course number is unique
    fileAppend.write(f'\n{courseTitle},{courseNumber}') # adds info to csv file
    fileAppend.close()
    
# enrolls a student in course by entering username and course number into csv file
def addNewEnrollment(studentUsername, courseNumber):
    fileAppend = open("enrollment.csv", 'a') # opens file in append mode
    fileRead = open("enrollment.csv", 'r') # opens file in read mode
    fileHeader = 'studentUsername,courseNumber' # file header for organization
    if fileHeader not in fileRead.read(): # if the file header hasn't been added yet
        fileAppend.write(fileHeader); 
    
    if os.path.isfile('studentLogin.csv') and os.path.isfile('courses.csv'): # checks if there is atleast one student and course existing
        correcting = True; 
        while correcting: # While making sure everything is valid and unique combination
            if courseNumber.lower() == 'end': # all if 'end' statements are so user can exit
                exit()
            elif courseNumber not in open('courses.csv', 'r').read(): # checks if course exists
                courseNumber = input("Course number must already be existing, please enter correct course number (If you would like to exit type 'end'): ") 
            
            if studentUsername.lower() == 'end':
                exit()
            elif studentUsername not in open('studentLogin.csv', 'r').read(): # Checks if student exists
                studentUsername = input("Student Username must already exist, please enter correct student username (If you would like to exit type 'end') :")
            
            if f'{studentUsername},{courseNumber}' in open("enrollment.csv",'r'): # Checks if course number and student username is unique
                print("Cannot enter duplicate username and course number, please try again.")
                courseNumber = input("Course Number: ")
                studentUsername = input("Student Username: ")
            elif courseNumber in open('courses.csv', 'r').read() and studentUsername in open('studentLogin.csv', 'r').read(): # if student and course numbe exist
                open('courses.csv', 'r').close()
                open('studentLogin.csv', 'r').close() 
                correcting = False
        fileAppend.write(f'\n{studentUsername},{courseNumber}') # add student and course number
        fileAppend.close()
        
        print(f'{studentUsername} has been enrolled in {courseNumber}')
    else: # No courses or no students
        print("\nEither missing courses or student file. Please make sure atleast one student is in the system as well as atleast one course.")

# lays out all info of a file organized with the header.
def seeAllInfo(fileName):
    if os.path.isfile(fileName): # checks if file exists
        fileRead = open(f'{fileName}', 'r') # open file in read mode
        rows = [] # so information can be stored
        header = next(fileRead) # puts header information into header
        for row in fileRead: # for every row after the header add it to rows
            rows.append(row + ',')
        print(f'\n{header}') # print out header
        print(rows) # print out info
        fileRead.close()
    else: # file doesn't exist, no info yet
        print("File does not exist. (Information needs to be added before using this feature.)") 
        
# Allows logged in admin to perform any task listed by entering corresponding number
def adminControl():
    adminTasks = True
    while adminTasks: # While admin wants to continue tasks
        print("\nSelect the number that corresponds with the task you would like to perform")
        print("1.) ADD NEW STUDENT \n2.) VIEW STUDENT INFO \n3.) CREATE NEW COURSE \n4.) VIEW COURSE INFO \n5.) ADD ENROLLMENT \n6.) VIEW ENROLLMENT \n7.) EXIT")
        selectedTask = input("") 
        if selectedTask == "7": # Exit program
            print("Goodbye")
            exit()
        elif selectedTask == "1": # Starts adding student task
            print("ENTER STUDENT INFO")
            print("If you would like to exit creating a new student enter end for any input for student.")
            # all if 'end': statements are for user to exit if desired, this whole block gathers new student info
            studentUsername = input("Student Username:").lower() 
            if studentUsername.lower() == "end":
                exit()
            studentPassword = input("Student Password: ").lower()
            if studentPassword.lower() == "end":
                exit()
            studentFirstName = input("Student First Name: ").lower()
            if studentFirstName.lower() == "end":
                exit()
            studentLastName = input("Student Last Name: ").lower()
            if studentLastName == "end":
                exit()
            
            addNewStudent(studentUsername, studentPassword, studentFirstName, studentLastName) # adds student info from user input
        elif selectedTask == '2': # display all student info
            print("ALL STUDENT INFO")
            print("=================\n")
            seeAllInfo('studentLogin.csv') # displays info with header
        elif selectedTask == '3':
            print("If you would like to go back type 'end' for any value")
            courseTitle = input("Enter Course Title: ").lower() # Gets desired course name
            if courseTitle.lower() == "end":
                exit()
            courseNumber = input("Enter Course Number: ").lower() # Gets desired course number
            if courseNumber.lower() == "end":
                exit()
            addNewCourse(courseTitle, courseNumber) # Adds new course from user input
            print("create course")
        elif selectedTask == '4':
            print("ALL COURSE INFO") # see all course info
            print("================")
            seeAllInfo('courses.csv') # displays all course info with header
        elif selectedTask == '5': # Starts enrollment task
            print("If you would like to exit, type 'end' for any information.")
            studentUsername = input("Type the username of student you would like to add to a course: ") # username of student being added
            if studentUsername.lower() == 'end': # exit if user types end
                exit()
            courseNumber = input(f"Type the course number you would like to enroll {studentUsername} in: ") # course number for student
            if courseNumber.lower() == 'end':
                exit()
            addNewEnrollment(studentUsername, courseNumber) # adds enrollment
        elif selectedTask == '6':
            seeAllInfo('enrollment.csv') # Displays all enrollment info

# Creates student class
def createStudent(username, password):
    fileRead = open('studentLogin.csv', 'r')  # opens student file in read mode
    checking = True; 
    
    while checking: # while checking information
        firstName = input('Enter first name: ') # first name for student
        lastName = input('Enter last name: ') # last name for student


        if f'{username},{password},{firstName},{lastName}' in fileRead.read(): # if info is correct
            currentStudent = Student(username,password,firstName,lastName)
            checking = False; 
            return currentStudent; 
        else:
            print("Please enter correct first and Last Name") # re-enter first and last name, username and password have been corrected before this function runs.
            
def displayCourses(studentUsername):
    if os.path.isfile('enrollment.csv'):
        fileRead = open('enrollment.csv', 'r'); 
        if studentUsername in fileRead:
            rows = []
            for row in fileRead:
                rows.append(row)
            if studentUsername in rows:
                rows.remove(studentUsername)
                print(rows)
            else:  
                print("Not Enrolled in any couress")  
        else:
            print(f"{studentUsername} is not enrolled in any coureses currently.")     
    else:
        print("Atleast one student has to be enrolled in a class from the Admin Module before viewing enrolled courses. ")