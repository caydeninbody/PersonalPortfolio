"""
    File Name: adminClass.py
    Purpose: 
        A child class of User class
    Variables created, in order of creation:
   username = username for Admin
   password = password for admin
    Functions
        __init__ = initializes class
        __str__ = returns a string format of the object
        setPassword = sets password property
        getPassword = gets password property
        setUsername = set username property
        getUsername = get username property
    First Create Date: 11/21/2023
    Last Update Date: 11/28/2023
    Author: Cayden Inbody
    Version: 0.1 """
from userClass import User;

class Admin(User):
    pass; # Admin uses same properties as User. 