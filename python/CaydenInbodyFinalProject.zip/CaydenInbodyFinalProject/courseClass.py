"""
    File Name: courseClass.py
    Purpose: 
        A child class of User class
    Variables created, in order of creation:
        courseName = Title of course
        courseNumber = Unique number associated with course
    Functions
        __init__ = initializes class
        __str__ = returns a string format of the object
        setCourseName = sets courseName property
        getCourseName = gets courseName property
        setCourseNumber = set courseNumber property
        getCourseNumber = get courseNumber property
    First Create Date: 11/21/2023
    Last Update Date: 11/28/2023
    Author: Cayden Inbody
    Version: 0.1 """
class Course():
    courseName = '' # Title of course
    courseNumber = '' # Unique number associated with course
    
    def __init__(s, courseName, courseNumber):
        s.courseName = courseName; 
        s.courseNumber = courseNumber; 
    
    def __str__(s):
        return f'Course Name: {s.courseName}\nCourse Number: {s.courseNumber}'
    
    def getCourseName(s):
        return s.courseName
    
    def getCourseNumber(s):
        return s.courseNumber; 
    
    def setCourseName(s, courseName):
        s.courseName = courseName; 
    
    def setCourseNumber(s, courseNumber):
        s.courseNumber = courseNumber; 