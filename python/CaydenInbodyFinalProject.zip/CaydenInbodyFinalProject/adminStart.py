"""
File Name: adminStart.py
Purpose: 
        Executable to run admin module. Will be able to add/view students, courses, and enrollment.
    Variables created, in order of creation:
        username = input for username
        password = input for password
        currentAdmin = creates Admin object
    Functions
        All imported from utilityFile.
    First Create Date: 11/24/2023
    Last Update Date: 11/28/2023
    Author: Cayden Inbody
    Version: 0.1 """
import utilityFile;  # imports utility file
from adminClass import Admin;  # imports admin class


print ("Welcome to the Admin file. You have 5 tries to login before getting kicked out.")

username = input("Enter username:\n") # username input
password = input("Enter password:\n") # password input
utilityFile.login(username,password,"admin.csv") # logs in based on user input
currentAdmin = Admin(username, password) # creates admin class based on user input

print(f"Hello {currentAdmin.username}")
utilityFile.adminControl() # displays admin controls and tasks

