"""
File Name: adminStart.py
Purpose: 
        Executable to run admin module. Will be able to add/view students, courses, and enrollment.
    Variables created, in order of creation:
        username = input for username
        password = input for password
        currentStudent = creates student object
    Functions
        All imported from utilityFile.
    First Create Date: 11/24/2023
    Last Update Date: 11/28/2023
    Author: Cayden Inbody
    Version: 0.1 """
import utilityFile; 
import csv; 
import os; 

print("Welcome to Student Module")
print("You only have 5 tries to login.")

username = input("Enter Username: ")
password = input("Enter Password: ")
utilityFile.login(username,password,'studentLogin.csv')

currentStudent = utilityFile.createStudent(username,password)    # creates object based on login info
print(f"All courses have been displayed for {currentStudent.firstName} {currentStudent.lastName}, goodbye") # Student module purpose is to view courses, task is complete